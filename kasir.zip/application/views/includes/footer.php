 <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 1.0.0
    </div>
    <strong>Copyright &copy; 2022 <a href="http://www.rajaputramedia.com" target="_blank">KASIR</a>.</strong> All rights
    reserved.
  </footer>