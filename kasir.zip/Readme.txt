1. Install XAMPP versi 7.3.9 or higher ke folder c:\ , sehingga menghasilkan direktory c:\xampp\

2. Kemudian aktifkan XAMPP Control Panel, klik START pada modul Apache dan MySQL

3. Extract file kasir.rar, sehingga menjadi folder "kasir"

4. Copy folder "kasir" ke c:\xampp\htdocs\kasir

5. Buka panel phpmyadmin via web browser, ketik url : localhost/phpmyadmin/

6. Buat database di panel phpmyadmin dengan nama "db_kasir"

7. Import database file SQL dari folder C:\xampp\htdocs\kasir\db_kasir.sql

8. Jalankan aplikasi via web browser, ketik url : localhost/kasir/

Login Administrator
Username : admin
Password : admin

Login Kasir
Username : kasir
Password : kasir

Raja Putra Media :)